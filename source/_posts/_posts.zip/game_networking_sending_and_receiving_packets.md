title: 游戏网络——数据包的接收和发送
date: 2015-08-24
layout: post
comments: true
categories: 网络
toc: true
tags: [Game]
keywords: 游戏, 网络, TCP, UDP, 数据包

---
# 0. 介绍
前面说了为什么不能选择TCP的网络连接的问题。选择UDP，这样数据包可以直接到达，而不用为了等待丢失包的重发，而所有的包都等待。下面回忆一下大学时候学习的有关网络编程相关的内容。

# 1. 套接字
熟悉Linux下的网络编程的话，都是知道，它是一套叫做BSD套接字API接口。BSD套接字包含了一系列网络相关的编程函数，如socket, bind, sendto 和 recvfrom等等。不过具体的平台还是存在一些小的差异，不过大致都大同小异。为了更具有通用性，将平台相关的细节都封装起来，提供统一的接口给客户端程序调用。

<!--more-->

# 2. 平台区分
首先，自定义平台，代码如下：

```
// 平台检测
#define PLATFORM_WINDOWS  1
#define PLATFORM_MAC      2
#define PLATFORM_UNIX     3
 
#if defined(_WIN32)
#define PLATFORM PLATFORM_WINDOWS
#elif defined(__APPLE__)
#define PLATFORM PLATFORM_MAC
#else
#define PLATFORM PLATFORM_UNIX
#endif
```
因为不同平台可能函数的声明的头文件名字不一样，所以，需要根据平台来包含特定的头文件，Windows，Mac，Linux平台头文件包含如下：

```
#if PLATFORM == PLATFORM_WINDOWS
 
#include <winsock2.h>
 
#elif PLATFORM == PLATFORM_MAC || PLATFORM == PLATFORM_UNIX
 
#include <sys/socket.h>
#include <netinet/in.h>
#include <fcntl.h>
 
#endif
```
可以看到只有Windows平台有些特殊。

套接字库在类Unix平台上都是内建的标准系统库，编译程序的时候没有必要去链接额外的库。但是在Windows平台下需要指定链接**winsock**库。所以，在头文件下面添加链接库的代码：

```
#if PLATFORM == PLATFORM_WINDOWS
#pragma comment( lib, "wsock32.lib" )
#endif
```

# 3. 初始化套接字
对于大多数的类Unix系统下，都不需要特别的步骤来初始化套接字。Windows平台下需要调用指定的方法（**WSAStartup**）去初始化套接字，使用完之后还需要调用指定的方法（**WSACleanup**）去关闭套接字库。所以，添加两个方法来完成套接字的初始化和关闭工作。

```
inline bool initializeSockets()
{
   #if PLATFORM == PLATFORM_WINDOWS
   WSADATA WsaData;
   return WSAStartup( MAKEWORD(2,2), &WsaData ) == NO_ERROR;
   #else
   return true;
   #endif
}
 
inline void shutdownSockets()
{
   #if PLATFORM == PLATFORM_WINDOWS
   WSACleanup();
   #endif
}
```

# 4. 创建套接字
下面的代码就是创建套接字：

```
int handle = socket( AF_INET, SOCK_DGRAM, IPPROTO_UDP );
 
if ( handle <= 0 )
{
   printf( "failed to create socket\n" );
   return false;
}
```
下一步我们绑定UDP的套接字到一个端口数字(例如. 30000)上。每一个套接字必须绑定一个唯一的端口，因为当一个数据包到达时，端口决定了哪一个套接字来传送它。不要使用小于1024的端口号，那些端口系统保留的。

一个特殊的情况：如果你不关心你的套接字的要绑定的端口，你可以传一个0作为你的端口号，那么系统将会分配你一个可用的端口。 

```
sockaddr_in address;
address.sin_family = AF_INET;
address.sin_addr.s_addr = INADDR_ANY;
address.sin_port = htons( (unsigned short) port );
 
if ( bind( handle, (const sockaddr*) &address, sizeof(sockaddr_in) ) < 0 )
{
    printf( "failed to bind socket\n" );
    return false;
}
```
现在这个套接字已经准备去发送和接收数据包了。但是，上面的代码中调用**htons** 略显奇怪。这个只是一个转换一个16bit的整数从主机 字节序(host byte order) (小端或者大端) 为网络字节序（大端）的辅助函数。每当你直接设置一个整数到套接字的结构体的时候最好先转换一下。

# 5. 设置套接字为无阻塞
上一节说到，套接字要是非阻塞的才可以。默认的情况下，套接字是设置为“阻塞模式”的。这个意思就是：如果你尝试使用“recvfrom” 来读取一个数据包，这个函数不会返回，直到有一个可读的数据包。这个是不符合我们的要求的。视频游戏是一个实时的程序，一般是在30或者60帧每秒。它们不可能停在那里等待数据包的到来。 
解决方法就是在创建套接字的时候将设置你的套接字为“非阻塞模式”。一旦做了这些， “recvfrom”函数当没有接收到包的时候也会立即返回。

下面就是如何将套接字变成非阻塞的模式：

```
#if PLATFORM == PLATFORM_MAC || PLATFORM == PLATFORM_UNIX
 
    int nonBlocking = 1;
    if ( fcntl( handle, F_SETFL, O_NONBLOCK, nonBlocking ) == -1 )
    {
        printf( "failed to set non-blocking socket\n" );
        return false;
    }
 
#elif PLATFORM == PLATFORM_WINDOWS
 
    DWORD nonBlocking = 1;
    if ( ioctlsocket( handle, FIONBIO, &nonBlocking ) != 0 )
    {
        printf( "failed to set non-blocking socket\n" );
        return false;
    }
 
#endif
```
Windows没有提供**fcntl**函数，所以我们使用**ioctlsocket**函数来代替。

# 5. 发送数据包
UDP是非连接的协议，所以每一次发送数据包时，都需要你指定发送的目标地址。你可以使用一个UDP的套接字给向不同的地址发送数据，没有一台计算机已连接到你的UDP套接字的另一端。 

下面是如何给制定的地址发送数据：

```
int sent_bytes = sendto( handle, (const char*)packet_data, packet_size,
                         0, (sockaddr*)&address, sizeof(sockaddr_in) );
 
if ( sent_bytes != packet_size )
{
    printf( "failed to send packet: return value = %d\n", sent_bytes );
    return false;
}
```
很重要的一点是：**sendto**函数的返回值只能表明在本地计算机发送数据是否成功。它是无法告诉你目标计算机是否接收到了该数据包！UDP没有一种知道数据包是否到达目标机器的方法。

在上面的代码中，我们传递了一个**sockaddr_t**的结构体作为目标地址。我们如何创建这样的一个结构体呢？
 
如果是我们想发送到地址207.45.186.98:30000。 代码如下：

```
unsigned int a = 207;
unsigned int b = 45;
unsigned int c = 186;
unsigned int d = 98;
unsigned short port = 30000;


unsigned int destination_address = ( a << 24 ) | ( b << 16 ) | ( c << 8 ) | d;
unsigned short destination_port = port;
 
sockaddr_in address;
address.sin_family = AF_INET;
address.sin_addr.s_addr = htonl( destination_address );
address.sin_port = htons( destination_port );
```
先将[0, 255]之间的a, b, c, d 组合为一个单个整数。我们接下来使用整形地址和端口初始化**sockaddr_in**结构体。 为了确保将整形地址转和端口化为网络字节序使用了**htonl**和**htons**。 

# 6. 接收数据包
一旦一个UDP的套接字绑定到一个端口，任何UDP数据包发送到你的套接字的地址和端 口后，数据包被放在了一个队列中。要接收这些数据只要你循环调用**recvfrom**，直到调用失败，就表示在队列里面没有剩余的数据包了。 因为UDP是无连接的，数据包可能来自于不同的计算机。每一次你接收到一个包，**recvfrom**都会把发送者的IP地址和端口告诉你，所以,你是知道包从哪里发送来的。

下面是如何循环接收所有来的数据包：

```
while ( true )
{
    unsigned char packet_data[256];
    unsigned int maximum_packet_size = sizeof( packet_data );
 
    #if PLATFORM == PLATFORM_WINDOWS
    typedef int socklen_t;
    #endif
 
    sockaddr_in from;
    socklen_t fromLength = sizeof( from );
 
    int received_bytes = recvfrom( socket, (char*)packet_data, maximum_packet_size,
                               0, (sockaddr*)&from, &fromLength );
 
    if ( received_bytes <= 0 )
        break;
 
    unsigned int from_address = ntohl( from.sin_addr.s_addr );
    unsigned int from_port = ntohs( from.sin_port );
 
    // 处理接收的包 
}
```
队列里面的包比你的缓冲区大的话，会默认把数据包丢弃掉。所以，如果你接收包的缓冲区的大小就像上面的代码一样是256字节，有人发送了一个300字节的数据包给你，那么这个300字节的数据包会被丢弃。你不可能只接收300字节的前面256字节。 
在你编写你的游戏网络协议的时候，实际中这个一点也不是一个问题，只需要保证你接收数据的缓冲区比你代码中可能发送的最大的数据包还要大就可以了。 

# 7. 销毁套接字
在大多数的类Unix平台上，套接字就是一个文件句柄，所以，你使用标准文件**close**函数去清理使用完成的套接字。然而，Windows有一点点不同，我们必须使用closesocket来代替：

```
#if PLATFORM == PLATFORM_MAC || PLATFORM == PLATFORM_UNIX
close( socket );
#elif PLATFORM == PLATFORM_WINDOWS
closesocket( socket );
#endif
```

# 8. Socket 类
上面关于Socket的基本操作如下

* 创建一个套接字。
* 绑定一个端口。
* 设置为“非阻塞模式”。
* 发送和接收数据包。
* 销毁套接字。 
但是，这些操作都有一点平台相关性，而且当你每一次想进行套接字操作时都必须记住使用**#ifdef**来做平台的区分，这是相当让人厌烦。最好的解决方法就是把这些平台相关的细节封装起来，给客户代码提供平台无关的接口。为了更好表示网络地址，增加一个“Address”的类。这样好让我们更好容易去指定一个网络地址。避免了每一次发送和接收数据时都必须手处理“sockaddr_in”的结构体。 

Socket类：

```
class Socket
{
public:
 
    Socket();
    ~Socket();
    bool Open( unsigned short port );
    void Close();
    bool IsOpen() const;
    bool Send( const Address & destination, const void * data, int size );
    int Receive( Address & sender, void * data, int size );
 
private:
 
    int handle;
};
```

Address类：

```
class Address
{
public:
 
    Address();
    Address( unsigned char a, unsigned char b, unsigned char c, unsigned char d, unsigned short port );
    Address( unsigned int address, unsigned short port );
    unsigned int GetAddress() const;
    unsigned char GetA() const;
    unsigned char GetB() const;
    unsigned char GetC() const;
    unsigned char GetD() const;
    unsigned short GetPort() const;
    bool operator == ( const Address & other ) const;
    bool operator != ( const Address & other ) const;
 
private:
 
    unsigned int address;
    unsigned short port;
};
```

下面是如何使用这些类来发送和接收数据包：

```
// 创建Socket
const int port = 30000;
Socket socket;
if ( !socket.Open( port ) )
{
    printf( "failed to create socket!\n" );
    return false;
}
 
// 发送数据包
const char data[] = "hello world!";
socket.Send( Address(127,0,0,1,port), data, sizeof( data ) );
 
// 接收数据包
while ( true )
{
    Address sender;
    unsigned char buffer[256];
    int bytes_read = socket.Receive( sender, buffer, sizeof( buffer ) );
    if ( !bytes_read )
        break;
    // 处理数据包
}
```
这样封装之后，它比直接使用BSD套接字要简单。这些代码在所有的平台上面都是一样的， 因为所有平台相关全部在Socket和Address内部处理了。



















